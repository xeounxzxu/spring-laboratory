IntelliJ Custom Icon SVG Pack (Dark)
Base artwork: spring-boot-dark-official-style-large.svg (scaled via width/height)

Mappings:
- Editor Gutter: springBoot_12_dark.svg and springBoot_12@2x_dark.svg
- Tool Window (Classic UI): springBoot_13_dark.svg and springBoot_13@2x_dark.svg
- Node/Action/File Type + New UI Compact: springBoot_16_dark.svg and springBoot_16@2x_dark.svg
- Tool Window (New UI): springBoot_20_dark.svg and springBoot_20@2x_dark.svg
